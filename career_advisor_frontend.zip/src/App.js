import React, { useState } from "react";

// Single-file React + Tailwind preview of the "Personalized Career & Skill Advisor" frontend
// Default export a React component (App). This is a starting point: hero, features, quiz, resume analyzer mock, roadmap, mock interview simulator UI.

export default function App() {
  const [active, setActive] = useState("home");
  const [quizScore, setQuizScore] = useState(null);
  const [resumeText, setResumeText] = useState("");
  const [showMock, setShowMock] = useState(false);

  const features = [
    {
      title: "Skill Gap Analysis",
      desc: "AI-driven suggestions that identify what you know and what to learn next.",
    },
    {
      title: "Personalized Roadmaps",
      desc: "Step-by-step learning plans tailored to your goals (student, job-seeker, entrepreneur).",
    },
    {
      title: "Resume Analyzer",
      desc: "Upload or paste your resume and get quick suggestions to improve ATS match.",
    },
    {
      title: "Mock Interviews",
      desc: "Practice with simulated interview questions and receive feedback.",
    },
  ];

  function takeSimpleQuiz() {
    // ultra simple mock quiz with a randomized score to simulate result
    const score = Math.floor(Math.random() * 41) + 60; // 60-100
    setQuizScore(score);
    setActive("dashboard");
  }

  function analyzeResume() {
    // placeholder — in a real app you'd send resumeText to backend/AI
    if (!resumeText.trim()) {
      alert("Paste your resume text in the box to analyze (demo mode).");
      return;
    }
    const suggestions = [];
    if (!resumeText.toLowerCase().includes("projects")) suggestions.push("Add a Projects section with measurable outcomes.");
    if (!resumeText.toLowerCase().includes("skills")) suggestions.push("List technical skills (languages, tools) clearly.");
    if (suggestions.length === 0) suggestions.push("Resume looks good for a basic check — consider tailoring to job descriptions.");
    alert("Resume suggestions (demo):\n" + suggestions.join("\n- "));
    setActive("dashboard");
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white text-gray-800">
      <header className="max-w-6xl mx-auto p-6 flex items-center justify-between">
        <h1 className="text-2xl font-extrabold">CareerGuide.AI</h1>
        <nav className="space-x-3">
          <button onClick={() => setActive("home")} className={`px-3 py-1 rounded ${active==='home'?'bg-indigo-600 text-white':'hover:bg-gray-100'}`}>Home</button>
          <button onClick={() => setActive("quiz")} className={`px-3 py-1 rounded ${active==='quiz'?'bg-indigo-600 text-white':'hover:bg-gray-100'}`}>Career Quiz</button>
          <button onClick={() => setActive("resume")} className={`px-3 py-1 rounded ${active==='resume'?'bg-indigo-600 text-white':'hover:bg-gray-100'}`}>Resume Analyzer</button>
          <button onClick={() => setActive("roadmap")} className={`px-3 py-1 rounded ${active==='roadmap'?'bg-indigo-600 text-white':'hover:bg-gray-100'}`}>Roadmap</button>
        </nav>
      </header>

      <main className="max-w-6xl mx-auto p-6">
        {/* Sections here (same as earlier code) */}
      </main>

      <footer className="mt-12 border-t py-6">
        <div className="max-w-6xl mx-auto text-center text-sm text-gray-500">© {new Date().getFullYear()} CareerGuide.AI — Demo frontend based on your idea</div>
      </footer>
    </div>
  );
}
